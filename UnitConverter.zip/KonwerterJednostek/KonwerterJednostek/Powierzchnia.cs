﻿namespace KonwerterJednostek
{
    internal class Powierzchnia
    {
        private decimal _m2;
        public Powierzchnia()
        {
            m2 = 0.0m;
        }
        public Powierzchnia(Jednostki jednostka, decimal wartosc)
        {
            if (wartosc >= 0)
            {
                switch (jednostka)
                {
                    case Jednostki.cm2:
                        m2 = wartosc / 10000m;
                        break;
                    case Jednostki.dm2:
                        m2 = wartosc / 100m;
                        break;
                    case Jednostki.m2:
                        m2 = wartosc;
                        break;
                    case Jednostki.a:
                        m2 = wartosc * 100m;
                        break;
                    case Jednostki.ha:
                        m2 = wartosc * 10000m;
                        break;
                    default:
                        break;
                }
            }
            else
                throw new ArgumentException("Wartosc nie może być ujemna");
        }
        public decimal cm2
        {
            get { return _m2 * 10000m; }
        }
        public decimal dm2
        {
            get { return _m2 * 100m; }
        }
        public decimal m2
        {
            get { return _m2; }
            set { _m2 = value; }
        }
        public decimal a
        {
            get { return _m2 / 100m; }
        }
        public decimal ha
        {
            get { return _m2 / 10000m; }
        }
    }
}
