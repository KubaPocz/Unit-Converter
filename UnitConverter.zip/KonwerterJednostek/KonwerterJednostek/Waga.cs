﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonwerterJednostek
{
    internal class Waga
    {
        private decimal _kg;
        public Waga()
        {
            kg = 0.0m;
        }
        public Waga(Jednostki jednostka, decimal wartosc)
        {
            if (wartosc >= 0)
            {
                switch (jednostka)
                {
                    case Jednostki.mg:
                        kg = wartosc /10000m;
                        break;
                    case Jednostki.g:
                        kg = wartosc /1000m;
                        break;
                    case Jednostki.dg:
                        kg = wartosc /100m;
                        break;
                    case Jednostki.kg:
                        kg = wartosc;
                        break;
                    case Jednostki.t:
                        kg = wartosc * 1000m;
                        break;
                    default:
                        break;
                }
            }
            else
                throw new ArgumentException("Wartosc nie może być ujemna");
        }
        public decimal mg
        {
            get { return _kg * 1000000m; }
        }
        public decimal g
        {
            get { return _kg * 1000m; }
        }
        public decimal dg
        {
            get { return _kg * 100m; }
        }
        public decimal kg
        {
            get { return _kg; }
            set { _kg = value; }
        }
        public decimal t
        {
            get { return _kg /1000m; }
        }
    }
}
