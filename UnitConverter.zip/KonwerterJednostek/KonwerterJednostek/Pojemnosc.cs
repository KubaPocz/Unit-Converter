﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonwerterJednostek
{
    internal class Pojemnosc
    {
        private decimal _l;
        public Pojemnosc()
        {
            l = 0.0m;
        }
        public Pojemnosc(Jednostki jednostka, decimal wartosc)
        {
            if (wartosc >= 0)
            {
                switch (jednostka)
                {
                    case Jednostki.ml:
                        l = wartosc / 1000m;
                        break;
                    case Jednostki.cl:
                        l = wartosc / 100m;
                        break;
                    case Jednostki.dl:
                        l = wartosc/10m;
                        break;
                    case Jednostki.l:
                        l = wartosc;
                        break;
                    case Jednostki.hl:
                        l = wartosc * 100m;
                        break;
                    default:
                        break;
                }
            }
            else
                throw new ArgumentException("Wartosc nie może być ujemna");
        }
        public decimal ml
        {
            get { return _l * 1000m; }
        }
        public decimal cl
        {
            get { return _l * 100m; }
        }
        public decimal dl
        {
            get { return _l * 10m; }
        }
        public decimal l
        {
            get { return _l; }
            set { _l = value; }
        }
        public decimal hl
        {
            get { return _l / 100m; }
        }
    }
}
