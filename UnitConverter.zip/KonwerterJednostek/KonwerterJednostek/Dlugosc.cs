﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonwerterJednostek
{
    internal class Dlugosc
    {
        private decimal _m;

        public Dlugosc(Jednostki jednostka, decimal wartosc)
        {
            if (wartosc >= 0)
            {
                switch (jednostka)
                {
                    case Jednostki.mm:
                        m = wartosc/1000;
                        break;
                    case Jednostki.cm:
                        m = wartosc/100;
                        break;
                    case Jednostki.dm:
                        m = wartosc/10;
                        break;
                    case Jednostki.m:
                        m = wartosc;
                        break;
                    case Jednostki.km:
                        m = wartosc*1000;
                        break;
                    default:
                        break;
                }
            }
            else
                throw new ArgumentException("Wartosc nie może być ujemna");
        }
        public Dlugosc()
        {
            m = 0.0m;
        }
        public decimal mm
        {
            get { return _m*1000; }
        }
        public decimal cm
        {
            get { return _m * 100; }
        }
        public decimal dm
        {
            get { return _m * 10; }
        }
        public decimal m
        {
            get { return _m; }
            set { _m = value; }
        }
        public decimal km
        {
            get { return _m / 1000; }
        }

    }
}
