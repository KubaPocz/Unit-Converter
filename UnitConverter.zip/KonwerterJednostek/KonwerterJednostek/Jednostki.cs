﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonwerterJednostek
{
    internal enum Jednostki
    {
        mm,
        cm,
        dm,
        m,
        km,
        mg,
        g,
        dg,
        kg,
        t,
        s,
        min,
        godz,
        dni,
        tyg,
        msc,
        lata,
        cm2,
        dm2,
        m2,
        a,
        ha,
        ml,
        cl,
        dl,
        l,
        hl,
        cm3,
        dm3,
        m3
    }
}
