﻿namespace KonwerterJednostek
{
    internal class Czas
    {
        private decimal _godz;
        public Czas()
        {
            godz = 0;
        }
        public Czas(Jednostki jednostka, decimal wartosc)
        {
            if (wartosc >= 0)
            {
                switch (jednostka)
                {
                    case Jednostki.s:
                        godz = wartosc / 3600m;
                        break;
                    case Jednostki.min:
                        godz = wartosc / 60m;
                        break;
                    case Jednostki.godz:
                        godz = wartosc;
                        break;
                    case Jednostki.dni:
                        godz = wartosc * 24m;
                        break;
                    case Jednostki.tyg:
                        godz = wartosc * 24m * 7;
                        break;
                    case Jednostki.msc:
                        godz = wartosc * 24m * 30.4m;
                        break;
                    case Jednostki.lata:
                        godz = wartosc * 24m * 365.25m;
                        break;
                    default:
                        break;
                }
            }
            else
                throw new ArgumentException("Wartosc nie może być ujemna");
        }
        public decimal s
        {
            get { return _godz * 3600m; }
        }
        public decimal min
        {
            get { return _godz * 60m; }
        }
        public decimal godz
        {
            get { return _godz; }
            set { _godz = value; }
        }
        public decimal dni
        {
            get { return _godz / 24.0m; }
        }
        public decimal tyg
        {
            get { return _godz / (24.0m * 7); }
        }
        public decimal msc
        {
            get { return _godz / (24.0m * 30.4m); }
        }
        public decimal lata
        {
            get { return _godz / (24.0m * 365.25m); }
        }
    }
}
