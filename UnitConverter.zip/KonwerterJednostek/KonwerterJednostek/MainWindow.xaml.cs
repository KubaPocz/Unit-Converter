﻿using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace KonwerterJednostek
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Category_ComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                ComboBoxItem Item;
                unit_ComboBox.Items.Clear();
                Type type;
                PropertyInfo[] properties;
                switch (selectedItem.Content)
                {
                    case "Długość":
                        type = typeof(Dlugosc);
                        properties = type.GetProperties();
                        foreach (var property in properties)
                        {
                            Item = new ComboBoxItem();
                            Item.Content = property.Name;
                            unit_ComboBox.Items.Add(Item);
                        }
                        break;
                    case "Czas":
                        type = typeof(Czas);
                        properties = type.GetProperties();
                        foreach (var property in properties)
                        {
                            Item = new ComboBoxItem();
                            Item.Content = property.Name;
                            unit_ComboBox.Items.Add(Item);
                        }
                        break;
                    case "Waga":
                        type = typeof(Waga);
                        properties = type.GetProperties();
                        foreach (var property in properties)
                        {
                            Item = new ComboBoxItem();
                            Item.Content = property.Name;
                            unit_ComboBox.Items.Add(Item);
                        }
                        break;
                    case "Powierzchnia":
                        type = typeof(Powierzchnia);
                        properties = type.GetProperties();
                        foreach (var property in properties)
                        {
                            Item = new ComboBoxItem();
                            Item.Content = property.Name;
                            unit_ComboBox.Items.Add(Item);
                        }
                        break;
                    case "Pojemność":
                        type = typeof(Pojemnosc);
                        properties = type.GetProperties();
                        foreach (var property in properties)
                        {
                            Item = new ComboBoxItem();
                            Item.Content = property.Name;
                            unit_ComboBox.Items.Add(Item);
                        }
                        break;
                    default: break;
                }
            }
        }
        private void ObliczButton_Click(object sender, RoutedEventArgs e)
        {
            if (Category_ComboBox.SelectedItem is ComboBoxItem selectedCategory && unit_ComboBox.SelectedItem is ComboBoxItem selectedUnit)
            {

                if (decimal.TryParse(value_TextBox.Text.Replace(".", ","), out var value))
                {
                    try
                    {
                        Type type;
                        PropertyInfo[] properties;
                        string info = "";
                        object? propValue;
                        switch (selectedCategory.Content)
                        {
                            case "Długość":
                                type = typeof(Dlugosc);
                                properties = type.GetProperties();
                                Enum.TryParse(unit_ComboBox.Text, out Jednostki jednostka_dl);
                                Dlugosc dl = new Dlugosc(jednostka_dl, value);
                                info += $"{value} {jednostka_dl.ToString()} to:\n\n";
                                foreach (PropertyInfo property in properties)
                                {
                                    propValue = property.GetValue(dl);
                                    info += $"{propValue:0.#####}{property.Name}  \n";
                                }
                                MessageBox.Show(info, "Wartości");
                                break;
                            case "Czas":
                                type = typeof(Czas);
                                properties = type.GetProperties();
                                Enum.TryParse(unit_ComboBox.Text, out Jednostki jednostka_cz);
                                Czas cz = new Czas(jednostka_cz, value);
                                info += $"{value} {jednostka_cz.ToString()} to:\n\n";
                                foreach (PropertyInfo property in properties)
                                {
                                    propValue = property.GetValue(cz);
                                    info += $"{propValue:0.#######}{property.Name}  \n";
                                }
                                MessageBox.Show(info, "Wartości");
                                break;
                            case "Waga":
                                type = typeof(Waga);
                                properties = type.GetProperties();
                                Enum.TryParse(unit_ComboBox.Text, out Jednostki jednostka_wa);
                                Waga wa = new Waga(jednostka_wa, value);
                                info += $"{value} {jednostka_wa.ToString()} to:\n\n";
                                foreach (PropertyInfo property in properties)
                                {
                                    propValue = property.GetValue(wa);
                                    info += $"{propValue:0.#####}{property.Name}  \n";
                                }
                                MessageBox.Show(info, "Wartości");
                                break;
                            case "Powierzchnia":
                                type = typeof(Powierzchnia);
                                properties = type.GetProperties();
                                Enum.TryParse(unit_ComboBox.Text, out Jednostki jednostka_pow);
                                Powierzchnia pow = new Powierzchnia(jednostka_pow, value);
                                info += $"{value} {jednostka_pow.ToString()} to:\n\n";
                                foreach (PropertyInfo property in properties)
                                {
                                    propValue = property.GetValue(pow);
                                    info += $"{propValue:0.#####}{property.Name}  \n";
                                }
                                MessageBox.Show(info, "Wartości");
                                break;
                            case "Pojemność":
                                type = typeof(Pojemnosc);
                                properties = type.GetProperties();
                                Enum.TryParse(unit_ComboBox.Text, out Jednostki jednostka_poj);
                                Pojemnosc poj = new Pojemnosc(jednostka_poj, value);
                                info += $"{value} {jednostka_poj.ToString()} to:\n\n";
                                foreach (PropertyInfo property in properties)
                                {
                                    propValue = property.GetValue(poj);
                                    info += $"{propValue:0.#####}{property.Name}  \n";
                                }
                                MessageBox.Show(info, "Wartości");
                                break;
                            default: break;
                        }
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message+"\nJeżeli uważasz, że coś jest nie tak, \nskontaktuj się z administratorem aplikacji.", "Error");
                    }
                }
                else
                {
                    MessageBox.Show("Błędna wartość, nie wpisuj liter!!");
                }
            }
            else
            {
                MessageBox.Show("Wybierz kategorie i jednostke miary.", "Błąd");
            }
        }
    }
}